{{/*
Expand the name of the chart.
*/}}
{{- define "app.name" -}}
{{- default .Chart.Name .Values.nameOverride | trunc 63 | trimSuffix "-" }}
{{- end }}

{{- define "app.fqdn" }}
{{- printf "%s%s.%s" .Values.nameOverride .Values.ingress.appUrlSuffix .Values.ingress.domain }}
{{- end }}

{{- define "app.domain" }}
{{- printf "%s" .Values.ingress.domain | trunc 63 | trimSuffix "-" }}
{{- end }}

{{/*
Create a default fully qualified app name.
We truncate at 63 chars because some Kubernetes name fields are limited to this (by the DNS naming spec).
If release name contains chart name it will be used as a full name.
*/}}
{{- define "app.fullname" -}}
{{- if .Values.fullnameOverride }}
{{- .Values.fullnameOverride | trunc 63 | trimSuffix "-" }}
{{- else }}
{{- $name := default .Chart.Name .Values.nameOverride }}
{{- if contains $name .Release.Name }}
{{- .Release.Name | trunc 63 | trimSuffix "-" }}
{{- else }}
{{- printf "%s-%s" .Release.Name $name | trunc 63 | trimSuffix "-" }}
{{- end }}
{{- end }}
{{- end }}

{{/*
Create chart name and version as used by the chart label.
*/}}
{{- define "app.chart" -}}
{{- printf "%s-%s" .Chart.Name .Chart.Version | replace "+" "_" | trunc 63 | trimSuffix "-" }}
{{- end }}

{{/*
Common labels
*/}}
{{- define "app.labels" -}}
helm.sh/chart: {{ include "app.chart" . }}
{{ include "app.selectorLabels" . }}
{{- if .Chart.AppVersion }}
app.kubernetes.io/version: {{ .Chart.AppVersion | quote }}
{{- end }}
app.kubernetes.io/managed-by: {{ .Release.Service }}
{{- end }}

{{/*
Selector labels
*/}}
{{- define "app.selectorLabels" -}}
app.kubernetes.io/name: {{ include "app.name" . }}
app.kubernetes.io/instance: {{ .Release.Name }}
{{- end }}

{{/*
Monitoring labels
*/}}
{{- define "app.monitoringLabels" -}}
{{- $tenantName := .Values.tenantName | required ".Values.tenantName is required." -}}
monitoring/instance: {{ $tenantName }}
{{- end }}

{{/*
Create the name of the service account to use
*/}}
{{- define "app.serviceAccountName" -}}
{{- if .Values.serviceAccount.create }}
{{- default (include "app.fullname" .) .Values.serviceAccount.name }}
{{- else }}
{{- default "default" .Values.serviceAccount.name }}
{{- end }}
{{- end }}

{{/* An immutable digest takes precedence over a mutable tag. */}}
{{- define "app.imageReference" -}}
{{- $root := .root -}}
{{- $suffix := .suffix | default "" -}}
{{- $digest := .digest | default "" -}}
{{- if $digest -}}
{{- if not (regexMatch "^sha256:[0-9a-f]{64}$" $digest) -}}
{{- fail "image digest must be a sha256 digest" -}}
{{- end -}}
{{- printf "%s%s@%s" $root.Values.image.repository $suffix $digest -}}
{{- else -}}
{{- printf "%s%s:%s" $root.Values.image.repository $suffix ($root.Values.image.tag | default $root.Chart.AppVersion | toString) -}}
{{- end -}}
{{- end -}}

{{/*
Render a per-path Service port, preserving the caller's legacy default when unset.
*/}}
{{- define "app.ingressServicePort" -}}
{{- $port := .path.servicePort -}}
{{- $error := "ingress path servicePort must be a port number (1-65535) or a valid Service port name" -}}
{{- if eq $port nil -}}
number: {{ .defaultPort }}
{{- else if kindIs "string" $port -}}
{{- if or (gt (len $port) 15) (not (regexMatch "^[a-z0-9]([-a-z0-9]*[a-z0-9])?$" $port)) (not (regexMatch "[a-z]" $port)) (contains "--" $port) -}}
{{- fail $error -}}
{{- end -}}
name: {{ $port | quote }}
{{- else -}}
{{- if not (regexMatch "^[0-9]+$" (toString $port)) -}}
{{- fail $error -}}
{{- end -}}
{{- if or (lt (float64 $port) 1.0) (gt (float64 $port) 65535.0) -}}
{{- fail $error -}}
{{- end -}}
number: {{ $port | int }}
{{- end -}}
{{- end -}}
